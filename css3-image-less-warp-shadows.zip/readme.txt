------------------
CSS3 Image-less Warp Shadows
A CSS3 technique.
Designed by Tyler Dawson (www.tyler-dawson.com) from USA
A simple CSS3 technique to apply warped shadows to elements.
------------------

Hey, there!

Thanks for downloading this technique.

You can freely use this technique for both your private and commercial projects, including software, online services, templates and themes. If you do something cool with it, let me know!
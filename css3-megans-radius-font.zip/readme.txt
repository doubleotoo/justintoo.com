------------------
CSS3 Megans RADius Font
A CSS+(X)HTML-based template.
Designed by Megan Brown-Taylor (www.megbee.com) from Honolulu, HI, USA
Description: I am a print/web designer who likes to play with CSS+HTML from time to time. I have a passion for experimental typography, and like to explore new ways of creating type. For this project, the font can be adjusted to change the into a totally different face just by changing a few small images. Enjoy!
------------------

Dear friends,

thank you for downloading this file.

You can freely use this template for both your private and commercial projects, including software, online services, templates and themes.